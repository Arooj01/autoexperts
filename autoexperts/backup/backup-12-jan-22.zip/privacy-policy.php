<?php include_once("brand-config.php"); ?>
<!doctype html>
<html class="no-js" lang="en">

<?php include_once('./include/head.php'); ?>

<body>

    <?php include_once('./include/header.php'); ?>

    <!--breadcumb -->
    <div class="breadcumb-wrapper breadcumb-layout1 background-image" data-img="assets/img/bg-img/breadcumb-bg.jpg">
        <div class="container">
            <div class="breadcumb-content">
                <!-- Breadcrumb Title -->
                <h1 class="breadcumb-title" data-aos="fade-left">Privacy Policy</h1>

                <!-- Breadcrumb Menu -->
                <ul>
                    <li><a href="/"> Home </a></li>
                    <li class="active">Privacy Policy</li>
                </ul>
            </div>
        </div>
    </div>
    <!--breadcumb end -->

    <!-- Privacy Policy Section -->
    <section class="price-plan-wrapper price-plan-layout1 pt-120">
        <div class="container">
            <div class="row">

                <div class="col-lg-12 " data-aos="fade-up">
                    <div class="price-plan-area">
                        
                        <h2>WHO WE ARE</h2>
                        <p>Our website address is: https://autoexpertworkshop.com/</p>
                        <h2>COOKIES</h2>
                        <p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p>
                        <p>We will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser. When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select "Remember Me", your login will persist for two weeks. If you log out of your account, the login cookies will be removed. If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p>
                        <h2>EMBEDDED CONTENT FROM OTHER WEBSITES</h2>
                        <p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p>
                        <p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p>
                        <h2>WHO WE SHARE YOUR DATA WITH</h2>
                        <p>If you request a password reset, your IP address will be included in the reset email.</p>
                        <h2>HOW LONG WE RETAIN YOUR DATA</h2>
                        <p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p>
                        <p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p>
                        <h2>WHAT RIGHTS YOU HAVE OVER YOUR DATA</h2>
                        <p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p>

                    </div>
                </div><!-- .col END -->

            </div><!-- .row END -->
        </div><!-- .container END -->
        <!-- Section Separator end -->
    </section>

    <!-- footer section start -->
    <?php include_once('./include/footer-area.php') ?>
    <!-- footer section end -->

    <!-- scroll to top -->
    <a href="#" class="scrollToTop"><i class="move"></i></a>

    <!-- Sidemenu Area -->
    <?php include_once('./sections/sidemenu-wrapper.php') ?>
    <!-- Sidemenu Area end -->

    <!-- js file start -->

    <!-- Jquery -->
    <?php include_once('./include/js.php') ?>
    <!-- End js file -->

</body>

</html>