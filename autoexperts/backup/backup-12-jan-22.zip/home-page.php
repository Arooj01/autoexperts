<?php include_once("brand-config.php"); ?>
<!doctype html>
<html class="no-js" lang="en">

<?php include_once('./include/head.php'); ?>

<body>

    <?php include_once('./include/header.php'); ?>

    <!-- About Us Section -->
    <?php include_once('./sections/about.php'); ?>
    <!-- About Us Section end -->

    <!-- Our Service -->
    <?php include_once('./sections/general-service.php'); ?>
    <!-- Our Service end -->

    <!-- Latest Project -->
    <?php include_once('./sections/latest-project.php'); ?>
    <!-- Latest Project end -->

    <!-- Work Process -->
    <?php include_once('./sections/work-process.php'); ?>
    <!-- Work Process end -->

    <!-- Our Features Area -->
    <?php include_once('./sections/our-featured.php') ?>
    <!-- Our Features Area end -->

    <!-- Our Service -->
    <?php include_once('./sections/specialized.php'); ?>
    <!-- Our Service end -->

    <!-- footer section start -->
    <?php include_once('./include/footer-area.php') ?>
    <!-- footer section end -->

    <!-- scroll to top -->
    <a href="#" class="scrollToTop"><i class="move"></i></a>

    <!-- Sidemenu Area -->
    <?php include_once('./sections/sidemenu-wrapper.php') ?>
    <!-- Sidemenu Area end -->

    <!-- js file start -->

    <!-- Jquery -->
    <?php include_once('./include/js.php') ?>
    <!-- End js file -->

</body>

</html>