    <section class="our-featured-wrapper featured-layout1 background-image pt-130 pb-130" data-img="assets/img/featured/featured-bg-1-1.jpg" id="featured">
        <div class="container">
            <div class="row text-center justify-content-center">
                <!-- Section Title -->
                <div class="col-md-10 col-lg-8 col-xl-6 " data-aos="fade-up">
                    <div class="section-title">
                        <h2 class="title">Why We Best?</h2>
                        <p>We Offer Full Auto Service, Repair & Maintenances.</p>
                    </div>
                </div>
            </div>


            <div class="row featured-slider-active " data-aos="fade-up">

                <!-- Single Featured -->
                <div class="col-xl-4">
                    <div class="single-featured">
                        <span class="shape"></span>
                        <div class="featured-icon">
                            <span class="circle-btn xl">
                                <i class="flaticon-agreement"></i>
                            </span>
                        </div>
                        <div class="featured-content">
                            <h3 class="title">Trusted</h3>
                            <p class="text">Here at Auto Expert Workshop we are providing outstanding customer service. After repairing your car with us, you will feel the difference.</p>
                        </div>
                    </div>
                </div>
                <!-- Single Featured -->
                <div class="col-xl-4">
                    <div class="single-featured">
                        <span class="shape"></span>
                        <div class="featured-icon">
                            <span class="circle-btn xl">
                                <i class="flaticon-award"></i>
                            </span>
                        </div>
                        <div class="featured-content">
                            <h3 class="title">Guarantees</h3>
                            <p class="text">We have well trained mechanics. Our technician will inspect your car and repair it. After repairing your car, We will do test drive for saving your time and cost.</p>
                        </div>
                    </div>
                </div>
                <!-- Single Featured -->
                <div class="col-xl-4">
                    <div class="single-featured">
                        <span class="shape"></span>
                        <div class="featured-icon">
                            <span class="circle-btn xl">
                                <i class="flaticon-consult"></i>
                            </span>
                        </div>
                        <div class="featured-content">
                            <h3 class="title">Support</h3>
                            <p class="text">At Auto Expert Workshop, We work on all brands cars with best packages to which suit to our customers needs.</p>
                        </div>
                    </div>
                </div>

            </div>


        </div>
    </section>