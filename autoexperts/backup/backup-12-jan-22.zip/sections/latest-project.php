    <section class="latest-project-wrapper background-image pt-120 pb-120" data-img="assets/img/bg-img/latest-project-1.jpg" id="project">
        <div class="container">
            <div class="row ">
                <!-- Section Title -->
                <div class="col-xl-5">
                    <div class="section-title">
                        <h2 class="title">If You Are Looking For Auto Workshop In Dubai?</h2>
                        <p class="text">We always take care of your car in our garage and the car will take care of you on the road. At AUTO EXPERT WORKSHOP, We work on all brands of Exotic, European & American cars with best packages which suit to our customers needs. Let's talk to our expert advisor!</p>
                        <h2 class="title">Call Now <a href="tel:+042999908">042999908</a></h2>
                    </div>
                </div>
                <!-- Section Title end -->


                <!-- Slider Area -->
                <div class="col-xl-7 position-static">
                    <div class="project-slider-area">
                        <!-- Thumb Logo -->
                        <div class="thumb-logo">
                            <img src="assets/img/thumb-logo.png" alt="Thumb Logo">
                        </div>
                        <!-- Slider Area -->
                        <div class="latProject-slider-active">
                            <img src="assets/img/latest-project/project-1-1.jpg" alt="Project Image">
                            <img src="assets/img/latest-project/project-1-2.jpg" alt="Project Image">
                        </div>

                    </div>
                </div>
                <!-- Slider Area end -->


            </div>
        </div>
    </section>