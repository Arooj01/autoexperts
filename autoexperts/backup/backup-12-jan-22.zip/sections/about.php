    <section class="about-us-sec about-wrap-layout1 spacing" id="about">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Title -->
                    <h2 class="about-title">Auto <span>Repair & Maintenance</span> in Dubai</h2>
                </div>
                <!-- About Us Image Area -->
                <div class="col-lg-5 col-xl-4">
                    <div class="about-us-left">
                        <!-- About US Image -->
                        <div class="about-us-img">
                            <img src="assets/img/about-us/about-us-img-1-1.jpg" alt="Auto Expert Workshop">
                        </div>
                        <!-- Experience Box -->
                        <div class="experiance-box d-md-flex">
                            <div class="icon">
                                <span><i class="flaticon-award"></i></span>
                            </div>
                            <div class="content">
                                <h2 class="main-title">Over 12 Years</h2>
                                <h3 class="title">Quality Auto Service</h3>
                                <p class="text">Get A Free Quote Now, Call Us For Inquiry.</p>
                                <h2 class="title d-block d-sm-none"><a href="tel:042999908">042999908</a></h2>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- About Us Image Area end -->
                <!-- About Us Content Area -->
                <div class="col-lg-7 col-xl-5">
                    <div class="about-us-content">
                        <h3 class="sub-title">Who <span>We Are?</span></h3>
                        <p class="text">We are highly specialized in engine / transmission & suspension repair, Rebuild & overhaul experts. Complete vehicle repair & service solutions, Economical prices, Friendly environment, Furnished sitting area with several animities providing fast, reliable & quality service. Below are some of the services we offer:</p>

                        <div class="row">
                            <div class="col-lg-6 col-xl-6">
                                <!-- Features List -->
                                <div class="features-list">
                                    <ul>
                                        <li>General Auto Repair</li>
                                        <li>Auto Brakes Service</li>
                                        <li>Auto Oil Change Service</li>
                                        <li>Car AC Repair & Service</li>
                                        <li>Auto Engine Repair / Rebuild</li>
                                        <li>Gearbox, Transmission Repair</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-lg-6 col-xl-6">
                                <!-- Features List -->
                                <div class="features-list">
                                    <ul>
                                        <li>Auto Suspension Repair</li>
                                        <li>Inspection</li>
                                        <li>Computer Diagnostics</li>
                                        <li>Body Shop Service</li>
                                        <li>Tyres Shop</li>
                                        <li>Steering Repair</li>
                                        <li>Auto Glass / Windscreen</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- About Us Content Area end -->
                <!-- Offer Widget -->
                <div class="col col-lg-4 col-xl-3">
                    <div class="widget widget_offer_banner">
                        <a href="contact.php" class="link-overlay"></a>
                        <h3 class="title">
                            <span class="text-white f-34">Services</span>
                            Your
                            <span class="text_medium f-47"><span class="text-white">Car</span> At</span>
                            <span class="text-white f-65">Very</span>
                            <span class="text_sm f-39">LOWEST</span>
                            <span class="text_medium f-48">PRICE</span>
                        </h3>

                        <div class="price-box">
                            <span class="text">Start</span>
                            <span class="price"><sup>AED</sup>299</span>
                            <span class="sub">/off</span>
                        </div>

                        <img src="assets/img/widget/offer-banner.png" alt="Offer Banner">

                    </div>
                </div>
                <!-- Offer Widget end -->
                <!-- Action Area -->
                <div class="col-lg-11 col-xl-8 offset-xl-4">
                    <div class="action-area d-md-flex justify-content-between align-items-center">
                        <div class="action-box-area d-sm-flex">
                            <!-- Single Action Box -->
                            <div class="action-box">
                                <div class="icon">
                                    <span><i class="flaticon-call"></i></span>
                                </div>
                                <div class="content">
                                    <span>Phone Number</span>
                                    <p class="text"><a href="tel:+042999908">042999908</a></p>
                                </div>
                            </div>
                            <!-- action Box -->
                            <div class="action-box">
                                <div class="icon">
                                    <span><i class="flaticon-envelope"></i></span>
                                </div>
                                <div class="content">
                                    <span>Email Address</span>
                                    <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                                </div>
                            </div>
                        </div>
                        <!-- Action Btn -->
                        <div class="action-btn">
                            <a href="contact.php" class="primary-btn no-shadow">Get Free Estimate</a>
                        </div>
                    </div>
                </div>
                <!-- Action Area end -->
            </div>
        </div>
    </section>