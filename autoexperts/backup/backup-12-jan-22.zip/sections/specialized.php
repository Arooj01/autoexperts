    <section class="service-layout4 our-service-wrapper spacing">
        <h2 class="sr-only">service-section</h2>
        <div class="container">
            <div class="row justify-content-center text-center">
                <!-- Section Title -->
                <div class="col-md-10 col-lg-8 col-xl-6 " data-aos="fade-up" data-aos-delay="100">
                    <div class="section-title">
                        <h2 class="title">We Are Specialized In</h2>
                        <p>We are specialized in all major auto brands, Highly specialized in engine / transmission & suspension repair, rebuild & overhaul experts.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center no-gutters" data-aos="fade-up">
                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <span class="service-icon"><img src="assets/img/brand/ferrari.jpg" alt="Ferrari"></span>
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Ferrari Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3">
                    <div class="service-box">
                        <img src="assets/img/brand/lamborghini.jpg" alt="Lamborghini">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Lamborghini Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/rolls-royce.jpg" alt="Rolls Royce">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Rolls Royce Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/bentley.jpg" alt="Bentley">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Bentley Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/aston-martin.jpg" alt="Aston Martin">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Aston Martin Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/audi.jpg" alt="Audi">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Audi Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/maserati.jpg" alt="Maserati">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Maserati Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/chevrolet.jpg" alt="Chevrolet">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Chevrolet Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/bmw.jpg" alt="BMW">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All BMW Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/porsche.jpg" alt="Porsche">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Porsche Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/mercedes.jpg" alt="Mercedes">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Mercedes Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/dodge.jpg" alt="Dodge">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Dodge Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/land-rover.jpg" alt="Land Rover">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Land Rover Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/ford.jpg" alt="Ford">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Ford Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/volkswagen.jpg" alt="Volkswagen">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Volkswagen Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/jaguar.jpg" alt="Jaguar">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Jaguar Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/infiniti.jpg" alt="Infiniti">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Infiniti Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/lexus.jpg" alt="Lexus">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Lexus Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/jeep.jpg" alt="Jeep">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Jeep Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/gmc.jpg" alt="GMC">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All GMC Models</h3>
                        </div>
                    </div>
                </div>

                <!-- Single Service -->
                <div class="col-sm-6 col-lg-4 col-xl-3 ">
                    <div class="service-box">
                        <img src="assets/img/brand/nissan.jpg" alt="Nissan">
                        <div class="service-content">
                            <h3 class="title" style="text-align: center;">We Work On All Nissan Models</h3>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>