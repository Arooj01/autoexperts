<?php include_once("brand-config.php"); ?>
<!doctype html>
<html class="no-js" lang="en">

<?php include_once('./include/head.php'); ?>

<body>

    <?php include_once('./include/header.php'); ?>

    <!--breadcumb -->
    <div class="breadcumb-wrapper breadcumb-layout1 background-image" data-img="assets/img/bg-img/breadcumb-bg.jpg">
        <div class="container">
            <div class="breadcumb-content">
                <!-- Breadcrumb Title -->
                <h1 class="breadcumb-title" data-aos="fade-left">Contact Us</h1>

                <!-- Breadcrumb Menu -->
                <ul>
                    <li><a href="/"> Home </a></li>
                    <li class="active">Contact Us</li>
                </ul>
            </div>
        </div>
    </div>
    <!--breadcumb end -->

    <!-- Contact Form -->
    <section class="contact-form-wrapper contact-form-layout3 pt-130 pb-100">
        <!-- Bg shape -->
        <div class="shape-bg">
            <img src="assets/img/contact-us/bg-shape-1.jpg" alt="Background Shape Image">
        </div>

        <div class="container">
            <div class="row justify-content-center" data-aos="fade-up">
                <!-- form Area -->
                <div class="col-lg-7 col-xl-8">
                    <div class="contact-form-area secondary-bg2">
                        <h2 class="form-title">Get A Free Quote Now</h2>
                        <h3 class="sub-title">We're always here to help you for your car</h3>
                        <!-- Contact Form -->
                        <form action="mail.php" class="contact-form" method="POST">
                            <div class="row gutters-20">
                                <!-- Single Input -->
                                <div class="col-md-6 form-group">
                                    <label for="name" class="sr-only">First Name</label>
                                    <input type="text" name="name" id="name" class="form-control" placeholder="First Name">
                                </div>
                                <!-- Single Input -->
                                <div class="col-md-6 form-group">
                                    <label for="lastName" class="sr-only">Last Name</label>
                                    <input type="text" name="lastName" id="lastName" class="form-control" placeholder="Last Name">
                                </div>
                                <!-- Single Input -->
                                <div class="col-md-6 form-group">
                                    <label for="email" class="sr-only">Email Address</label>
                                    <input type="email" name="email" id="email" class="form-control" placeholder="Email Address">
                                </div>
                                <!-- Single Input -->
                                <div class="col-md-6 form-group">
                                    <label for="number" class="sr-only">Mobile Number</label>
                                    <input type="tel" name="number" id="number" class="form-control" placeholder="Mobile Number">
                                </div>
                                <!-- Single Input -->
                                <div class="col-12 form-group">
                                    <label for="subject" class="sr-only">Subjects</label>
                                    <input type="text" name="subject" id="subject" class="form-control" placeholder="Subjects">
                                </div>
                                <!-- Single Input -->
                                <div class="col-12 form-group">
                                    <label for="message" class="sr-only">Message</label>
                                    <textarea class="form-control" id="message" name="message" placeholder="Write a Message...."></textarea>
                                </div>
                                <!-- Form Button -->
                                <div class="col-12 form-group mb-0 pt-2">
                                    <button class="primary-btn" type="submit">Send Message</button>
                                </div>
                            </div>
                        </form>
                        <p class="form-messages"></p>
                        <!-- Contact Form end -->
                    </div>
                </div>
                <!-- form Area end -->

                <!-- Contact information Area -->
                <div class="col-lg-5 col-xl-4">
                    <div class="contact-information-area background-image" data-img="assets/img/contact-us/contact-information-img-1-1.jpg">
                        <!-- Box Area title  -->
                        <div class="area-title">
                            <h4 class="title">Our Information</h4>
                            <p class="text">We are highly specialized in engine / transmission & suspension repair, rebuild & overhaul experts. Complete vehicle repair & service solutions.</p>
                        </div>
                        <!-- Information Box -->
                        <div class="info-box">
                            <div class="icon">
                                <span><i class="fal fa-envelope"></i></span>
                            </div>
                            <div class="content">
                                <span>Mail Us</span>
                                <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                            </div>
                        </div>
                        <!-- Information Box -->
                        <div class="info-box">
                            <div class="icon">
                                <span><i class="fas fa-phone-alt"></i></span>
                            </div>
                            <div class="content">
                                <span>Get In Touch</span>
                                <p class="text"><a href="tel:+042999908">042999908</a></p>
                            </div>
                        </div>
                        <!-- Information Box -->
                        <div class="info-box">
                            <div class="icon">
                                <span><i class="fal fa-map-marker-alt"></i></span>
                            </div>
                            <div class="content">
                                <span>Our Location</span>
                                <p class="text">Auto Expert Workshop, Near 24 Fitness, Al Quoz 1, Dubai</p>
                            </div>
                        </div>
                        <!-- Information Box -->
                        <div class="info-box">
                            <div class="icon">
                                <span><i class="fal fa-clock"></i></span>
                            </div>
                            <div class="content">
                                <span>Working Hours</span>
                                <p class="text">Sat - Thu: 08:00 AM - 06:00 PM <br> Fri: day off</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact information Area end -->
            </div><!-- .row END -->
        </div><!-- .container END -->
    </section>
    <!-- Contact Form end -->

    <!-- branch Information Area -->
    <div class="axivis-branch-information branch-information-layout1 ">
        <div class="container">
            <!-- Branch Information Slider Active -->
            <div class="inner-wrapper branchInfo-slider-active " data-aos="fade-up">
                <!-- Single Branch Information -->
                <div class="single-branch-info">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <!-- Branch Info Header -->
                            <div class="branch-info-head">
                                <!-- Branch Image -->
                                <div class="branch-img">
                                    <img src="assets/img/contact-us/branch-img-1.jpg" alt="Branch Image">
                                </div>
                            </div>
                            <!-- Branch Info Header -->
                        </div><!-- .col END -->
                        <div class="col-lg-6">
                            <!-- branch info body -->
                            <div class="branch-info-body">
                                <h2 class="branch-title">Auto Expert Workshop</h2>
                                <p class="branch-location"><i class="fas fa-map-marker-alt"></i>Auto Expert Workshop, Near 24 Fitness, Al Quoz 1, Dubai</p>
                                <!-- Branch Information Area -->
                                <div class="branch-info">
                                    <!-- Singele Info -->
                                    <div class="info-box">
                                        <div class="icon">
                                            <span><i class="fas fa-phone-alt"></i></span>
                                        </div>
                                        <div class="content">
                                            <span>Get In Touch</span>
                                            <p class="text"><a href="tel:+042999908">042999908</a></p>
                                        </div>
                                    </div>
                                    <!-- Singele Info -->
                                    <div class="info-box">
                                        <div class="icon">
                                            <span><i class="fal fa-envelope"></i></span>
                                        </div>
                                        <div class="content">
                                            <span>Mail Us</span>
                                            <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Branch Information Area -->
                                <a href="mailto:info@autoexpertworkshop.com" class="primary-btn">Contact Us</a>
                                <!-- map button -->
                                <a href="#google-map" class="map-button button scroll-down">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span class="ripple ripple-1"></span>
                                    <span class="ripple ripple-2"></span>
                                    <span class="ripple ripple-3"></span>
                                </a>
                            </div>
                            <!-- branch info body end -->
                        </div><!-- .col END -->
                    </div><!-- .row END -->
                </div>
                <!-- Single Branch Information end -->



                <!-- Single Branch Information -->
                <div class="single-branch-info">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <!-- Branch Info Header -->
                            <div class="branch-info-head">
                                <!-- Branch Image -->
                                <div class="branch-img">
                                    <img src="assets/img/contact-us/branch-img-2.jpg" alt="Branch Image">
                                </div>
                            </div>
                            <!-- Branch Info Header -->
                        </div><!-- .col END -->
                        <div class="col-lg-6">
                            <!-- branch info body -->
                            <div class="branch-info-body">
                                <h2 class="branch-title">Auto Expert Workshop</h2>
                                <p class="branch-location"><i class="fas fa-map-marker-alt"></i>Auto Expert Workshop, Near 24 Fitness, Al Quoz 1, Dubai</p>
                                <!-- Branch Information Area -->
                                <div class="branch-info">
                                    <!-- Singele Info -->
                                    <div class="info-box">
                                        <div class="icon">
                                            <span><i class="fas fa-phone-alt"></i></span>
                                        </div>
                                        <div class="content">
                                            <span>Get In Touch</span>
                                            <p class="text"><a href="tel:+042999908">042999908</a></p>
                                        </div>
                                    </div>
                                    <!-- Singele Info -->
                                    <div class="info-box">
                                        <div class="icon">
                                            <span><i class="fal fa-envelope"></i></span>
                                        </div>
                                        <div class="content">
                                            <span>Mail Us</span>
                                            <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Branch Information Area -->
                                <a href="mailto:info@autoexpertworkshop.com" class="primary-btn">Contact Us</a>
                                <!-- map button -->
                                <a href="#google-map" class="map-button button scroll-down">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span class="ripple ripple-1"></span>
                                    <span class="ripple ripple-2"></span>
                                    <span class="ripple ripple-3"></span>
                                </a>
                            </div>
                            <!-- branch info body end -->
                        </div><!-- .col END -->
                    </div><!-- .row END -->
                </div>
                <!-- Single Branch Information end -->



                <!-- Single Branch Information -->
                <div class="single-branch-info">
                    <div class="row align-items-center">
                        <div class="col-lg-6">
                            <!-- Branch Info Header -->
                            <div class="branch-info-head">
                                <!-- Branch Image -->
                                <div class="branch-img">
                                    <img src="assets/img/contact-us/branch-img-3.jpg" alt="Branch Image">
                                </div>
                            </div>
                            <!-- Branch Info Header -->
                        </div><!-- .col END -->
                        <div class="col-lg-6">
                            <!-- branch info body -->
                            <div class="branch-info-body">
                                <h2 class="branch-title">Auto Expert Workshop</h2>
                                <p class="branch-location"><i class="fas fa-map-marker-alt"></i>Auto Expert Workshop, Near 24 Fitness, Al Quoz 1, Dubai</p>
                                <!-- Branch Information Area -->
                                <div class="branch-info">
                                    <!-- Singele Info -->
                                    <div class="info-box">
                                        <div class="icon">
                                            <span><i class="fas fa-phone-alt"></i></span>
                                        </div>
                                        <div class="content">
                                            <span>Get In Touch</span>
                                            <p class="text"><a href="tel:+042999908">042999908</a></p>
                                        </div>
                                    </div>
                                    <!-- Singele Info -->
                                    <div class="info-box">
                                        <div class="icon">
                                            <span><i class="fal fa-envelope"></i></span>
                                        </div>
                                        <div class="content">
                                            <span>Mail Us</span>
                                            <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- Branch Information Area -->
                                <a href="mailto:info@autoexpertworkshop.com" class="primary-btn">Contact Us</a>
                                <!-- map button -->
                                <a href="#google-map" class="map-button button scroll-down">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <span class="ripple ripple-1"></span>
                                    <span class="ripple ripple-2"></span>
                                    <span class="ripple ripple-3"></span>
                                </a>
                            </div>
                            <!-- branch info body end -->
                        </div><!-- .col END -->
                    </div><!-- .row END -->
                </div>
                <!-- Single Branch Information end -->



            </div>
        </div><!-- .container END -->
    </div>
    <!-- branch Information Area end -->

    <!-- Google Map Area -->
    <div class="contact-map-wrap ">
        <div class="contact-map" id="google-map"></div>
    </div>
    <!-- Google Map Area end -->

    <!-- footer section start -->
    <?php include_once('./include/footer-area.php') ?>
    <!-- footer section end -->

    <!-- scroll to top -->
    <a href="#" class="scrollToTop"><i class="move"></i></a>

    <!-- Sidemenu Area -->
    <?php include_once('./sections/sidemenu-wrapper.php') ?>
    <!-- Sidemenu Area end -->

    <!-- Jquery -->
    <?php include_once('./include/js.php') ?>
    <!-- End js file -->

</body>

</html>