<?php
$brand_page = false;
$brand_config = array(
        'head'=>'',
        'header'=>'',
        'about_section'=>'',
        'general_service'=>'',
        'work_process_section'=>'',
        'latest_project_section'=>'',
        'our_featured_section'=>'',
        'specialized_section'=>'',
        'sidemenu'=>''
    );
	
/*****************************************************************************************
All Cars Maintenance
******************************************************************************************/

/*** Audi Maintenance Dubai ***/
if(isset($_GET['audi-maintenance-dubai'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

?>