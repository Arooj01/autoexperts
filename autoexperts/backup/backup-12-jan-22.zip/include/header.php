    <!-- Mobile Menu -->
    <div class="mobile-menu-wrapper ">
        <div class="mean-menu-area">
            <!-- Menu Close Btn -->
            <button class="mobileMenucls"><i class="fal fa-times"></i></button>

            <!-- Mobile Menu -->
            <div class="mobile-logo">
                <a href="/"><img src="assets/img/logo.png" alt="Auto Expert Workshop"></a>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu"></div><!-- Menu Will Append With Javascript -->

        </div>
    </div>
    <!-- Mobile Menu end -->

    <!-- Sticky Header -->
    <div class="sticky-header-wrap sticky-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-6 col-md-3">
                    <div class="logo">
                        <a href="/"><img src="assets/img/logo-h3.png" alt="Auto Expert Workshop"></a>
                    </div>
                </div>
                <div class="col-6 col-md-9 text-right">
                    <nav class="main-menu">
                        <ul>
                            <li class="menu-item-has-children">
                                <a href="/">Home</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="about.php">About</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="specialized.php">Specialized In</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="general-service.php">General Services</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="contact.php">Contact Us</a>
                            </li>
                        </ul>
                    </nav>
                    <!-- Mobile Menu Toggle Btn -->
                    <button class="menuToggleBtn d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
                </div>
            </div>
        </div>
    </div>
    <!-- Sticky Header end -->

    <!-- Header Top -->
    <div class="header-top-layout1">
        <!-- Header top area end -->
        <!-- header Middle Area -->
        <div class="header-middle-area">
            <div class="container">
                <div class="row aling-items-center">
                    <div class="col-lg-12 col-xl-12 d-flex" data-aos="fade-down">
                        <!-- action Box -->
                        <div class="action-box d-flex  align-items-center">
                            <div class="icon">
                                <span class="shape-icon"><i class="fal fa-clock"></i></span>
                            </div>
                            <div class="content">
                                <span>Saturday To Thursday</span>
                                <p class="text">8:00 am - 6:00 pm</p>
                            </div>
                        </div>

                        <!-- action Box -->
                        <div class="action-box d-flex align-items-center">
                            <div class="icon">
                                <span class="shape-icon"><i class="fal fa-envelope"></i></span>
                            </div>
                            <div class="content">
                                <span>Contact Us</span>
                                <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                            </div>
                        </div>

                        <!-- action Box -->
                        <div class="action-box d-flex align-items-center">
                            <div class="icon">
                                <span class="shape-icon"><i class="fal fa-phone"></i></span>
                            </div>
                            <div class="content">
                                <span>Call Us</span>
                                <p class="text"><a href="tel:+042999908">042999908</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Phone Box -->
                <div class="phone-box d-none d-xl-flex align-items-center">
                    <div class="icon">
                        <a href="tel:+042999908"><i class="fas fa-phone"></i></a>
                    </div>
                    <div class="content">
                        <span>SUPPORT & ORDER</span>
                        <a href="tel:+042999908">042999908</a>
                    </div>
                </div>

            </div>
        </div>
        <!-- header Middle Area end -->
    </div>
    <!-- Header Top end -->

    <!-- Header Area -->
    <header class='header-layout1'>
        <div class="container">
            <div class="row align-items-center">
                <!-- Logo -->
                <div class="col-4 col-lg-3 col-xl-3" data-aos="fade-right">
                    <div class="header-logo">
                        <a href="/"><img src="assets/img/logo.png" alt="Auto Expert Workshop"></a>
                    </div>
                </div>

                <!-- Main Menu Area -->
                <div class="col-8 col-lg-8 col-xl-6 text-right" data-aos="fade-down">
                    <nav class="main-menu">
                        <ul>
                            <li class="menu-item-has-children">
                                <a href="/">Home</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="about.php">About</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="specialized.php">Specialized In</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="general-service.php">General Services</a>
                            </li>
                            <li class="menu-item-has-children">
                                <a href="contact.php">Contact Us</a>
                            </li>
                        </ul>
                    </nav>
                    <!-- Mobile Menu Toggle Btn -->
                    <button class="menuToggleBtn d-inline-block d-lg-none"><i class="far fa-bars"></i></button>
                </div>
                <!-- Main Menu Area end -->
                <!-- Header Btn -->
                <div class="col-lg-1 col-xl-3 text-right" data-aos="fade-left">
                    <div class="header-btn">
                        <a href="contact.php" class="primary-btn d-none d-xl-inline-block no-shadow">Get Free Estimate</a>
                        <button class="sidebarToggler d-none d-lg-inline-block"><i class="far fa-bars"></i></button>
                    </div>
                </div>
                <!-- Header Btn end -->
            </div>
        </div>
    </header>
    <!-- Header Area end -->