    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
    <!-- Slick Slider -->
    <script src="assets/js/slick.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Counter Up -->
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <!-- Select Box -->
    <script src="assets/js/select2.min.js"></script>
    <!-- Popup Box -->
    <script src="assets/js/jquery.fancybox.min.js"></script>
    <!-- Layer Slider -->
    <script src="assets/js/greensock.min.js"></script>
    <script src="assets/js/layerslider.transitions.js"></script>
    <script src="assets/js/layerslider.kreaturamedia.jquery.js"></script>
    <!-- Date & Time Picker -->
    <script src="assets/js/jquery.datetimepicker.min.js"></script>
    <!-- Circle Progress Bar -->
    <script src="assets/js/circle-progress.min.js"></script>
    <!-- AOS Scroll Animation -->
    <script src="assets/js/aos.min.js"></script>
    <!-- Isotop Filter -->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>
    <script src="assets/js/isotope.pkgd.min.js"></script>
    <!-- Vecuro Carousel -->
    <script src="assets/js/vscustom-carousel.min.js"></script>
    <!-- Ajax Mail -->
    <script src="assets/js/ajaxmail.js"></script>
    <!-- Google Map js -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAFyFD_hcbzJFSZ4Dvdx2kn5NWBaGC_eMU"></script>
    <!-- Main Js File -->
    <script src="assets/js/main.js"></script>