<!doctype html>
<html class="no-js" lang="en">

<?php include_once('./include/head.php'); ?>

<body>

    <!-- Header Area -->
    <?php include_once('./include/header.php'); ?>

    <!--breadcumb -->
    <div class="breadcumb-wrapper breadcumb-layout1 background-image" data-img="assets/img/bg-img/breadcumb-bg.jpg">
        <div class="container">
            <div class="breadcumb-content">
                <!-- Breadcrumb Title -->
                <h1 class="breadcumb-title" data-aos="fade-left">About US</h1>

                <!-- Breadcrumb Menu -->
                <ul>
                    <li><a href="/"> Home </a></li>
                    <li class="active">About</li>
                </ul>
            </div>
        </div>
    </div>
    <!--breadcumb end -->

    <!-- About Us Section -->
    <section class="about-us-sec about-wrap-layout5 pt-100 pb-100">

        <div class="container">
            <div class="row gutters-50 ">
                <!-- About Us Image Area -->
                <div class="col-xl-6" data-aos="fade-right" data-aos-delay="100">
                    <!-- About US Image -->
                    <div class="about-us-img">
                        <!-- Image Big -->
                        <div class="big-img">
                            <img src="assets/img/about-us/about-us-img-5-1.jpg" alt="About Us Image">
                        </div>
                        <div class="small-img">
                            <img src="assets/img/about-us/about-us-img-5-2.jpg" alt="About Us Image">
                        </div>
                        <!-- Experiance -->
                        <div class="experiance">
                            <span>25</span>
                        </div>
                    </div>
                </div>
                <!-- About Us Image Area end -->
                <!-- About Us Content Area -->
                <div class="col-xl-6" data-aos="fade-left" data-aos-delay="100">
                    <div class="about-us-content">
                        <h2 class="about-title">WE <span>Work</span> For You</h2>
                        <h3 class="sub-title">Best Car Repair & Maintenance Center In Dubai.</h3>
                        <p>We are highly specialized in engine / transmission & suspension repair, Rebuild & overhaul experts. Complete vehicle repair & service solutions, Economical prices, Friendly environment, Furnished sitting area with several animities providing fast, reliable & quality service. Below are some of the services we offer.</p>

                        <!-- Features List -->
                        <div class="features-list">
                            <ul>
                                <li>General Auto Repair</li>
                                <li>Auto Brakes Service</li>
                                <li>Auto Oil Change Service</li>
                                <li>Car AC Repair & Service</li>
                                <li>Auto Engine Repair / Rebuild</li>
                                <li>Auto Gearbox, Transmission Repair</li>
                                <li>Auto Suspension Repair</li>
                                <li>Auto Inspection</li>
                                <li>Auto Computer Diagnostics</li>
                                <li>Auto Body Shop Service</li>
                                <li>Auto Tyres Shop</li>
                                <li>Auto Steering Repair</li>
                                <li>Auto Glass / Windscreen</li>
                            </ul>
                        </div>
                        <div class="action-box-area d-sm-flex">
                            <!-- Single Action Box -->
                            <div class="action-box">
                                <div class="icon">
                                    <span><i class="flaticon-call"></i></span>
                                </div>
                                <div class="content">
                                    <span>Phone Number</span>
                                    <p class="text"><a href="tel:+042999908">042999908</a></p>
                                </div>
                            </div>
                            <!-- action Box -->
                            <div class="action-box">
                                <div class="icon">
                                    <span><i class="flaticon-envelope"></i></span>
                                </div>
                                <div class="content">
                                    <span>Email Address</span>
                                    <p class="text"><a href="mailto:info@autoexpertworkshop.com">info@autoexpertworkshop.com</a></p>
                                </div>
                            </div>
                        </div>
                        <!-- Action Btn -->
                    </div>
                </div>
                <!-- About Us Content Area end -->
            </div>
        </div>
    </section>
    <!-- About Us Section end -->

    <!-- Counter Area -->
    <div class="counter-area-wrap counter-layout4 pt-120 pb-120 ">
        <div class="container">
            <div class="inner-wrapper">
                <div class="row justify-content-center " data-aos="fade-up" data-aos-delay="1100">

                    <!-- Single Counter -->
                    <div class="col-sm-6 col-xl-3">
                        <div class="counter-box">
                            <div class="icon">
                                <span class="shape-icon">
                                    <i class="flaticon-mission"></i>
                                </span>
                            </div>
                            <div class="content">
                                <span class="counter">12</span>
                                <p class="text text-primary">Years Of Experience In Dubai</p>
                            </div>

                        </div>
                    </div>
                    <!-- Single Counter -->
                    <div class="col-sm-6 col-xl-3">
                        <div class="counter-box">
                            <div class="icon">
                                <span class="shape-icon">
                                    <i class="flaticon-worker"></i>
                                </span>
                            </div>
                            <div class="content">
                                <span class="counter">33</span>
                                <p class="text text-primary">Technician & Workers</p>
                            </div>

                        </div>
                    </div>
                    <!-- Single Counter -->
                    <div class="col-sm-6 col-xl-3">
                        <div class="counter-box">
                            <div class="icon">
                                <span class="shape-icon">
                                    <i class="flaticon-team"></i>
                                </span>
                            </div>
                            <div class="content">
                                <span class="counter">2534</span>
                                <p class="text text-primary">Satisfied Customers</p>
                            </div>

                        </div>
                    </div>
                    <!-- Single Counter -->
                    <div class="col-sm-6 col-xl-3">
                        <div class="counter-box">
                            <div class="icon">
                                <span class="shape-icon">
                                    <i class="flaticon-taxi"></i>
                                </span>
                            </div>
                            <div class="content">
                                <span class="counter">4550</span>
                                <p class="text text-primary">Vehicle Repaired</p>
                            </div>

                        </div>
                    </div>



                </div><!-- .row END -->
            </div><!-- inner Wrapper -->
        </div><!-- .container END -->
    </div>
    <!-- Counter Area end -->

    <!-- Brand Area -->
    <?php include_once('./sections/brand-area.php') ?>
    <!-- Brand Area end -->

    <!-- footer section start -->
    <?php include_once('./include/footer-area.php') ?>
    <!-- footer section end -->

    <!-- scroll to top -->
    <a href="#" class="scrollToTop"><i class="move"></i></a>

    <!-- Sidemenu Area -->
    <?php include_once('./sections/sidemenu-wrapper.php') ?>
    <!-- Sidemenu Area end -->

    <!-- Jquery -->
    <?php include_once('./include/js.php') ?>
    <!-- End js file -->

</body>

</html>