<!doctype html>
<html class="no-js" lang="en">

<?php include_once('./include/head.php'); ?>

<body>

    <!-- Header Area -->
    <?php include_once('./include/header.php'); ?>

    <!--breadcumb -->
    <div class="breadcumb-wrapper breadcumb-layout1 background-image" data-img="assets/img/bg-img/repaire-est-bg-1-1.jpg">
        <div class="container">
            <div class="breadcumb-content" style="padding: 90px 0px;">
                <!-- Breadcrumb Title -->
                <h1 class="breadcumb-title" data-aos="fade-left">What We Do</h1>

                <!-- Breadcrumb Menu -->
                <ul>
                    <li><a href="/"> Home </a></li>
                    <li class="active">Specialized In</li>
                </ul>
            </div>
        </div>
    </div>
    <!--breadcumb end -->

    <!-- Our Service -->
    <?php include_once('./sections/specialized.php'); ?>
    <!-- Our Service end -->

    <!-- Our Service -->
    <?php include_once('./sections/general-service.php'); ?>
    <!-- Our Service end -->

    <!-- Work Process -->
    <?php include_once('./sections/work-process.php'); ?>

    <!-- footer section start -->
    <?php include_once('./include/footer-area.php') ?>
    <!-- footer section end -->

    <!-- scroll to top -->
    <a href="#" class="scrollToTop"><i class="move"></i></a>

    <!-- Sidemenu Area -->
    <?php include_once('./sections/sidemenu-wrapper.php') ?>
    <!-- Sidemenu Area end -->

    <!-- Jquery -->
    <?php include_once('./include/js.php') ?>

</body>

</html>