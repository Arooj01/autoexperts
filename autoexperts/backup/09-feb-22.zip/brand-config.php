<?php
$brand_page = false;
$brand_config = array(
    'head'=>'',
    'header'=>'',
    'about_section'=>'',
    'general_service'=>'',
    'work_process_section'=>'',
    'latest_project_section'=>'',
    'our_featured_section'=>'',
    'specialized_section'=>'',
    'footer_area'=>''
);

/*****************************************************************************************
Audi Cars Maintenance
******************************************************************************************/

/*** Audi Maintenance ***/
if(isset($_GET['audi-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Maintenance Dubai ***/
if(isset($_GET['audi-maintenance-dubai'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-maintenance-dubai";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Car Maintenance ***/
if(isset($_GET['audi-car-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-car-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Car Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Car Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A1 Maintenance ***/
if(isset($_GET['audi-a1-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a1-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A1";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A1 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A3 Maintenance ***/
if(isset($_GET['audi-a3-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a3-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A3 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A4 Maintenance ***/
if(isset($_GET['audi-a4-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a4-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A4";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A4 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a4.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A5 Maintenance ***/
if(isset($_GET['audi-a5-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a5-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A5 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A6 Maintenance ***/
if(isset($_GET['audi-a6-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a6-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A6";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A6 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a6.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A7 Maintenance ***/
if(isset($_GET['audi-a7-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a7-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A7 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi A8 Maintenance ***/
if(isset($_GET['audi-a8-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-a8-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi A8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi A8 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q2 Maintenance ***/
if(isset($_GET['audi-q2-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-q2-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi Q2";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Q2 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q2.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q3 Maintenance ***/
if(isset($_GET['audi-q3-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-q3-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi Q3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Q3 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q5 Maintenance ***/
if(isset($_GET['audi-q5-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-q5-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi Q5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Q5 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q7 Maintenance ***/
if(isset($_GET['audi-q7-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-q7-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi Q7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Q7 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q8 Maintenance ***/
if(isset($_GET['audi-q8-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-q8-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi Q8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Q8 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi R8 Maintenance ***/
if(isset($_GET['audi-r8-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-r8-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi R8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi R8 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-r8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi S3 Maintenance ***/
if(isset($_GET['audi-s3-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-s3-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi S3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi S3 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS3 Maintenance ***/
if(isset($_GET['audi-rs3-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-rs3-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi RS3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi RS3 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi S4 Maintenance ***/
if(isset($_GET['audi-s4-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-s4-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi S4";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi S4 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s4.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS4 Maintenance ***/
if(isset($_GET['audi-rs4-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-rs4-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi RS4";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi RS4 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs4.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi S5 Maintenance ***/
if(isset($_GET['audi-s5-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-s5-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi S5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi S5 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS5 Maintenance ***/
if(isset($_GET['audi-rs5-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-rs5-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi RS5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi RS5 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi S6 Maintenance ***/
if(isset($_GET['audi-s6-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-s6-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi S6";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi S6 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s6.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS6 Maintenance ***/
if(isset($_GET['audi-rs6-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-rs6-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi RS6";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi RS6 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs6.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi S7 Maintenance ***/
if(isset($_GET['audi-s7-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-s7-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi S7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi S7 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS7 Maintenance ***/
if(isset($_GET['audi-rs7-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-rs7-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi RS7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi RS7 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi S8 Maintenance ***/
if(isset($_GET['audi-s8-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-s8-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi S8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi S8 Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi TT Maintenance ***/
if(isset($_GET['audi-tt-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-tt-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi TT";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi TT Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-tt.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi E Tron Maintenance ***/
if(isset($_GET['audi-e-tron-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-e-tron-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi e-tron";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Maintenance.';
    $brand_config['header_li_3'] = 'Audi Transmission Maintenance.';
    $brand_config['header_li_4'] = 'Audi Suspension Maintenance.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_6'] = 'Audi AC Repair & Maintenance.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Maintenance.';
    $brand_config['header_li_9'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_10'] = 'Audi Wheel Balance Maintenance.';
    $brand_config['header_li_11'] = 'Audi Battery Maintenance.';
    $brand_config['header_li_12'] = 'Audi Tires Maintenance.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen.';
    $brand_config['header_li_17'] = 'Audi Electrical System Maintenance.';
    $brand_config['header_li_18'] = 'Audi Lighting System Maintenance.';
    $brand_config['header_li_19'] = 'Audi Steering Maintenance.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi e-tron Maintenance In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-e-tron.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Aston Martin Cars Maintenance
******************************************************************************************/

/*** Aston Martin Maintenance ***/
if(isset($_GET['aston-martin-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Cygnet Maintenance ***/
if(isset($_GET['aston-martin-cygnet-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-cygnet-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Cygnet";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-cygnet.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB10 Maintenance ***/
if(isset($_GET['aston-martin-db10-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-db10-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB10";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB11 Maintenance ***/
if(isset($_GET['aston-martin-db11-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-db11-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB11";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-db11.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB7 Maintenance ***/
if(isset($_GET['aston-martin-db7-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-db7-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-db7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB9 Maintenance ***/
if(isset($_GET['aston-martin-db9-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-db9-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB9";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-db9.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DBS Maintenance ***/
if(isset($_GET['aston-martin-dbs-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-dbs-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DBS";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-dbs.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Lagonda Maintenance ***/
if(isset($_GET['aston-martin-lagonda-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-lagonda-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Lagonda";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-lagonda.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin One 77 Maintenance ***/
if(isset($_GET['aston-martin-one-77-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-one-77-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin One 77";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-one-77.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Rapide Maintenance ***/
if(isset($_GET['aston-martin-rapide-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-rapide-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Rapide";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-rapide.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Vanquish Maintenance ***/
if(isset($_GET['aston-martin-vanquish-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-vanquish-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Vanquish";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-vanquish.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Vantage Maintenance ***/
if(isset($_GET['aston-martin-vantage-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-vantage-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Vantage";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-vantage.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Virage Maintenance ***/
if(isset($_GET['aston-martin-virage-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-virage-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Virage";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-virage.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Vulcan Maintenance ***/
if(isset($_GET['aston-martin-vulcan-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-vulcan-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Vulcan";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-vulcan.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Zagato Maintenance ***/
if(isset($_GET['aston-martin-zagato-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?aston-martin-zagato-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Zagato";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-zagato.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Repair
******************************************************************************************/

/*** Audi Repair ***/
if(isset($_GET['audi-repair-dubai'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-repair-dubai";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Audi Transmission Repair.';
    $brand_config['header_li_4'] = 'Audi Suspension Repair.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Repair.';
    $brand_config['header_li_9'] = 'Audi Engine Repair.';
    $brand_config['header_li_10'] = 'Audi Wheel Repair.';
    $brand_config['header_li_11'] = 'Audi Battery Repair.';
    $brand_config['header_li_12'] = 'Audi Tires Repair.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** BMW Car Repair ***/
if(isset($_GET['bmw-car-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?bmw-car-repair";
    
    // Brand Name
    $brand_config['brand'] = "BMW";
    $brand_config['brand_title'] = "Car Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'BMW Transmission Repair.';
    $brand_config['header_li_4'] = 'BMW Suspension Repair.';
    $brand_config['header_li_5'] = 'BMW Brake Pads Repair.';
    $brand_config['header_li_6'] = 'BMW AC Service & Repair.';
    $brand_config['header_li_7'] = 'BMW Oil Change Service.';
    $brand_config['header_li_8'] = 'BMW Gearbox Repair.';
    $brand_config['header_li_9'] = 'BMW Engine Repair.';
    $brand_config['header_li_10'] = 'BMW Wheel Repair.';
    $brand_config['header_li_11'] = 'BMW Battery Repair.';
    $brand_config['header_li_12'] = 'BMW Tires Repair.';
    $brand_config['header_li_13'] = 'BMW Computer Reprogram.';
    $brand_config['header_li_14'] = 'BMW Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'BMW Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'BMW Electrical System Repair.';
    $brand_config['header_li_18'] = 'BMW Lighting System Repair.';
    $brand_config['header_li_19'] = 'BMW Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized BMW Car Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/bmw.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/bmw.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/bmw/bmw-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Mercedes Car Repair ***/
if(isset($_GET['mercedes-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?mercedes-repair";
    
    // Brand Name
    $brand_config['brand'] = "Mercedes";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Mercedes Transmission Repair.';
    $brand_config['header_li_4'] = 'Mercedes Suspension Repair.';
    $brand_config['header_li_5'] = 'Mercedes Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Mercedes AC Service & Repair.';
    $brand_config['header_li_7'] = 'Mercedes Oil Change Service.';
    $brand_config['header_li_8'] = 'Mercedes Gearbox Repair.';
    $brand_config['header_li_9'] = 'Mercedes Engine Repair.';
    $brand_config['header_li_10'] = 'Mercedes Wheel Repair.';
    $brand_config['header_li_11'] = 'Mercedes Battery Repair.';
    $brand_config['header_li_12'] = 'Mercedes Tires Repair.';
    $brand_config['header_li_13'] = 'Mercedes Computer Reprogram.';
    $brand_config['header_li_14'] = 'Mercedes Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Mercedes Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Mercedes Electrical System Repair.';
    $brand_config['header_li_18'] = 'Mercedes Lighting System Repair.';
    $brand_config['header_li_19'] = 'Mercedes Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Mercedes Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/mercedes.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/mercedes.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/mercedes/mercedes-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Porsche Car Repair ***/
if(isset($_GET['porsche-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?porsche-repair";
    
    // Brand Name
    $brand_config['brand'] = "Porsche";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Porsche Transmission Repair.';
    $brand_config['header_li_4'] = 'Porsche Suspension Repair.';
    $brand_config['header_li_5'] = 'Porsche Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Porsche AC Service & Repair.';
    $brand_config['header_li_7'] = 'Porsche Oil Change Service.';
    $brand_config['header_li_8'] = 'Porsche Gearbox Repair.';
    $brand_config['header_li_9'] = 'Porsche Engine Repair.';
    $brand_config['header_li_10'] = 'Porsche Wheel Repair.';
    $brand_config['header_li_11'] = 'Porsche Battery Repair.';
    $brand_config['header_li_12'] = 'Porsche Tires Repair.';
    $brand_config['header_li_13'] = 'Porsche Computer Reprogram.';
    $brand_config['header_li_14'] = 'Porsche Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Porsche Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Porsche Electrical System Repair.';
    $brand_config['header_li_18'] = 'Porsche Lighting System Repair.';
    $brand_config['header_li_19'] = 'Porsche Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Porsche Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/porsche.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/porsche-car.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/porsche/porsche-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Land Rover Repair ***/
if(isset($_GET['land-rover-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?land-rover-repair";
    
    // Brand Name
    $brand_config['brand'] = "Land Rover";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Land Rover Transmission Repair.';
    $brand_config['header_li_4'] = 'Land Rover Suspension Repair.';
    $brand_config['header_li_5'] = 'Land Rover Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Land Rover AC Service & Repair.';
    $brand_config['header_li_7'] = 'Land Rover Oil Change Service.';
    $brand_config['header_li_8'] = 'Land Rover Gearbox Repair.';
    $brand_config['header_li_9'] = 'Land Rover Engine Repair.';
    $brand_config['header_li_10'] = 'Land Rover Wheel Repair.';
    $brand_config['header_li_11'] = 'Land Rover Battery Repair.';
    $brand_config['header_li_12'] = 'Land Rover Tires Repair.';
    $brand_config['header_li_13'] = 'Land Rover Computer Reprogram.';
    $brand_config['header_li_14'] = 'Land Rover Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Land Rover Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Land Rover Electrical System Repair.';
    $brand_config['header_li_18'] = 'Land Rover Lighting System Repair.';
    $brand_config['header_li_19'] = 'Land Rover Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Land Rover Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/land-rover.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/land-rover-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/land-rover/land-rover.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Range Rover Repair ***/
if(isset($_GET['range-rover-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?range-rover-repair";
    
    // Brand Name
    $brand_config['brand'] = "Range Rover";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Range Rover Transmission Repair.';
    $brand_config['header_li_4'] = 'Range Rover Suspension Repair.';
    $brand_config['header_li_5'] = 'Range Rover Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Range Rover AC Service & Repair.';
    $brand_config['header_li_7'] = 'Range Rover Oil Change Service.';
    $brand_config['header_li_8'] = 'Range Rover Gearbox Repair.';
    $brand_config['header_li_9'] = 'Range Rover Engine Repair.';
    $brand_config['header_li_10'] = 'Range Rover Wheel Repair.';
    $brand_config['header_li_11'] = 'Range Rover Battery Repair.';
    $brand_config['header_li_12'] = 'Range Rover Tires Repair.';
    $brand_config['header_li_13'] = 'Range Rover Computer Reprogram.';
    $brand_config['header_li_14'] = 'Range Rover Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Range Rover Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Range Rover Electrical System Repair.';
    $brand_config['header_li_18'] = 'Range Rover Lighting System Repair.';
    $brand_config['header_li_19'] = 'Range Rover Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Range Rover Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/land-rover.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/land-rover-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/land-rover/range-rover.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Volkswagen Repair ***/
if(isset($_GET['volkswagen-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?volkswagen-repair";
    
    // Brand Name
    $brand_config['brand'] = "Volkswagen";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Volkswagen Transmission Repair.';
    $brand_config['header_li_4'] = 'Volkswagen Suspension Repair.';
    $brand_config['header_li_5'] = 'Volkswagen Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Volkswagen AC Service & Repair.';
    $brand_config['header_li_7'] = 'Volkswagen Oil Change Service.';
    $brand_config['header_li_8'] = 'Volkswagen Gearbox Repair.';
    $brand_config['header_li_9'] = 'Volkswagen Engine Repair.';
    $brand_config['header_li_10'] = 'Volkswagen Wheel Repair.';
    $brand_config['header_li_11'] = 'Volkswagen Battery Repair.';
    $brand_config['header_li_12'] = 'Volkswagen Tires Repair.';
    $brand_config['header_li_13'] = 'Volkswagen Computer Reprogram.';
    $brand_config['header_li_14'] = 'Volkswagen Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Volkswagen Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Volkswagen Electrical System Repair.';
    $brand_config['header_li_18'] = 'Volkswagen Lighting System Repair.';
    $brand_config['header_li_19'] = 'Volkswagen Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Volkswagen Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/volkswagen.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/volkswagen-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/volkswagen/volkswagen.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Mini Cooper Repair ***/
if(isset($_GET['mini-cooper-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?mini-cooper-repair";
    
    // Brand Name
    $brand_config['brand'] = "Mini Cooper";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Mini Cooper Transmission Repair.';
    $brand_config['header_li_4'] = 'Mini Cooper Suspension Repair.';
    $brand_config['header_li_5'] = 'Mini Cooper Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Mini Cooper AC Repair.';
    $brand_config['header_li_7'] = 'Mini Cooper Oil Change Service.';
    $brand_config['header_li_8'] = 'Mini Cooper Gearbox Repair.';
    $brand_config['header_li_9'] = 'Mini Cooper Engine Repair.';
    $brand_config['header_li_10'] = 'Mini Cooper Wheel Repair.';
    $brand_config['header_li_11'] = 'Mini Cooper Battery Repair.';
    $brand_config['header_li_12'] = 'Mini Cooper Tires Repair.';
    $brand_config['header_li_13'] = 'Mini Cooper Computer Reprogram.';
    $brand_config['header_li_14'] = 'Mini Cooper Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Mini Cooper Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Mini Cooper Electrical System Repair.';
    $brand_config['header_li_18'] = 'Mini Cooper Lighting System Repair.';
    $brand_config['header_li_19'] = 'Mini Cooper Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Mini Cooper Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/mini-cooper.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/mini-cooper-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/mini-cooper/mini-cooper.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Jaguar Repair ***/
if(isset($_GET['jaguar-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?jaguar-repair";
    
    // Brand Name
    $brand_config['brand'] = "Jaguar";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Jaguar Transmission Repair.';
    $brand_config['header_li_4'] = 'Jaguar Suspension Repair.';
    $brand_config['header_li_5'] = 'Jaguar Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Jaguar AC Service & Repair.';
    $brand_config['header_li_7'] = 'Jaguar Oil Change Service.';
    $brand_config['header_li_8'] = 'Jaguar Gearbox Repair.';
    $brand_config['header_li_9'] = 'Jaguar Engine Repair.';
    $brand_config['header_li_10'] = 'Jaguar Wheel Repair.';
    $brand_config['header_li_11'] = 'Jaguar Battery Repair.';
    $brand_config['header_li_12'] = 'Jaguar Tires Repair.';
    $brand_config['header_li_13'] = 'Jaguar Computer Reprogram.';
    $brand_config['header_li_14'] = 'Jaguar Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Jaguar Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Jaguar Electrical System Repair.';
    $brand_config['header_li_18'] = 'Jaguar Lighting System Repair.';
    $brand_config['header_li_19'] = 'Jaguar Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Jaguar Car Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/jaguar.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/jaguar-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/jaguar/jaguar-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Ford Repair ***/
if(isset($_GET['ford-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?ford-repair";
    
    // Brand Name
    $brand_config['brand'] = "Ford";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Ford Transmission Repair.';
    $brand_config['header_li_4'] = 'Ford Suspension Repair.';
    $brand_config['header_li_5'] = 'Ford Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Ford AC Service & Repair.';
    $brand_config['header_li_7'] = 'Ford Oil Change Service.';
    $brand_config['header_li_8'] = 'Ford Gearbox Repair.';
    $brand_config['header_li_9'] = 'Ford Engine Repair.';
    $brand_config['header_li_10'] = 'Ford Wheel Repair.';
    $brand_config['header_li_11'] = 'Ford Battery Repair.';
    $brand_config['header_li_12'] = 'Ford Tires Repair.';
    $brand_config['header_li_13'] = 'Ford Computer Reprogram.';
    $brand_config['header_li_14'] = 'Ford Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Ford Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Ford Electrical System Repair.';
    $brand_config['header_li_18'] = 'Ford Lighting System Repair.';
    $brand_config['header_li_19'] = 'Ford Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Ford Car Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/ford.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/ford-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/ford/ford-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** GMC Repair ***/
if(isset($_GET['gmc-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?gmc-repair";
    
    // Brand Name
    $brand_config['brand'] = "GMC";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'GMC Car Transmission Repair.';
    $brand_config['header_li_4'] = 'GMC Car Suspension Repair.';
    $brand_config['header_li_5'] = 'GMC Car Brake Pads Repair.';
    $brand_config['header_li_6'] = 'GMC Car AC Service & Repair.';
    $brand_config['header_li_7'] = 'GMC Car Oil Change Service.';
    $brand_config['header_li_8'] = 'GMC Car Gearbox Repair.';
    $brand_config['header_li_9'] = 'GMC Car Engine Repair.';
    $brand_config['header_li_10'] = 'GMC Car Wheel Repair.';
    $brand_config['header_li_11'] = 'GMC Car Battery Repair.';
    $brand_config['header_li_12'] = 'GMC Car Tires Repair.';
    $brand_config['header_li_13'] = 'GMC Car Computer Reprogram.';
    $brand_config['header_li_14'] = 'GMC Car Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'GMC Car Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'GMC Car Electrical System Repair.';
    $brand_config['header_li_18'] = 'GMC Car Lighting System Repair.';
    $brand_config['header_li_19'] = 'GMC Car Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized GMC Car Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/gmc.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/gmc-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/gmc/gmc-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Dodge Repair ***/
if(isset($_GET['dodge-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?dodge-repair";
    
    // Brand Name
    $brand_config['brand'] = "Dodge";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Dodge Transmission Repair.';
    $brand_config['header_li_4'] = 'Dodge Suspension Repair.';
    $brand_config['header_li_5'] = 'Dodge Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Dodge AC Service & Repair.';
    $brand_config['header_li_7'] = 'Dodge Oil Change Service.';
    $brand_config['header_li_8'] = 'Dodge Gearbox Repair.';
    $brand_config['header_li_9'] = 'Dodge Engine Repair.';
    $brand_config['header_li_10'] = 'Dodge Wheel Repair.';
    $brand_config['header_li_11'] = 'Dodge Battery Repair.';
    $brand_config['header_li_12'] = 'Dodge Tires Repair.';
    $brand_config['header_li_13'] = 'Dodge Computer Reprogram.';
    $brand_config['header_li_14'] = 'Dodge Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Dodge Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Dodge Electrical System Repair.';
    $brand_config['header_li_18'] = 'Dodge Lighting System Repair.';
    $brand_config['header_li_19'] = 'Dodge Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Dodge Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/dodge.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/dodge-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/dodge/dodge-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Cadillac Repair ***/
if(isset($_GET['cadillac-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?cadillac-repair";
    
    // Brand Name
    $brand_config['brand'] = "Cadillac";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Cadillac Transmission Repair.';
    $brand_config['header_li_4'] = 'Cadillac Suspension Repair.';
    $brand_config['header_li_5'] = 'Cadillac Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Cadillac AC Service & Repair.';
    $brand_config['header_li_7'] = 'Cadillac Oil Change Service.';
    $brand_config['header_li_8'] = 'Cadillac Gearbox Repair.';
    $brand_config['header_li_9'] = 'Cadillac Engine Repair.';
    $brand_config['header_li_10'] = 'Cadillac Wheel Repair.';
    $brand_config['header_li_11'] = 'Cadillac Battery Repair.';
    $brand_config['header_li_12'] = 'Cadillac Tires Repair.';
    $brand_config['header_li_13'] = 'Cadillac Computer Reprogram.';
    $brand_config['header_li_14'] = 'Cadillac Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Cadillac Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Cadillac Electrical System Repair.';
    $brand_config['header_li_18'] = 'Cadillac Lighting System Repair.';
    $brand_config['header_li_19'] = 'Cadillac Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Cadillac Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/cadillac-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/cadillac-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/cadillac/cadillac-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Nissan Patrol Repair ***/
if(isset($_GET['nissan-patrol-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?nissan-patrol-repair";
    
    // Brand Name
    $brand_config['brand'] = "Nissan Patrol";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Nissan Transmission Repair.';
    $brand_config['header_li_4'] = 'Nissan Suspension Repair.';
    $brand_config['header_li_5'] = 'Nissan Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Nissan AC Service & Repair.';
    $brand_config['header_li_7'] = 'Nissan Oil Change Service.';
    $brand_config['header_li_8'] = 'Nissan Patrol Gearbox Repair.';
    $brand_config['header_li_9'] = 'Nissan Patrol Engine Repair.';
    $brand_config['header_li_10'] = 'Nissan Patrol Wheel Repair.';
    $brand_config['header_li_11'] = 'Nissan Patrol Battery Repair.';
    $brand_config['header_li_12'] = 'Nissan Patrol Tires Repair.';
    $brand_config['header_li_13'] = 'Nissan Computer Reprogram.';
    $brand_config['header_li_14'] = 'Nissan Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Nissan Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Nissan Electrical System Repair.';
    $brand_config['header_li_18'] = 'Nissan Lighting System Repair.';
    $brand_config['header_li_19'] = 'Nissan Patrol Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Nissan Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/nissan.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/nissan-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/nissan/nissan-patrol-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Jeep Repair ***/
if(isset($_GET['jeep-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?jeep-repair";
    
    // Brand Name
    $brand_config['brand'] = "Jeep";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Jeep Transmission Repair.';
    $brand_config['header_li_4'] = 'Jeep Suspension Repair.';
    $brand_config['header_li_5'] = 'Jeep Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Jeep AC Service & Repair.';
    $brand_config['header_li_7'] = 'Jeep Oil Change Service.';
    $brand_config['header_li_8'] = 'Jeep Gearbox Repair.';
    $brand_config['header_li_9'] = 'Jeep Engine Repair.';
    $brand_config['header_li_10'] = 'Jeep Wheel Repair.';
    $brand_config['header_li_11'] = 'Jeep Battery Repair.';
    $brand_config['header_li_12'] = 'Jeep Tires Repair.';
    $brand_config['header_li_13'] = 'Jeep Computer Reprogram.';
    $brand_config['header_li_14'] = 'Jeep Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Jeep Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Jeep Electrical System Repair.';
    $brand_config['header_li_18'] = 'Jeep Lighting System Repair.';
    $brand_config['header_li_19'] = 'Jeep Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Jeep Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/jeep.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/jeep-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/jeep/jeep-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Infiniti Repair ***/
if(isset($_GET['infiniti-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?infiniti-repair";
    
    // Brand Name
    $brand_config['brand'] = "Infiniti";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Infiniti Transmission Repair.';
    $brand_config['header_li_4'] = 'Infiniti Suspension Repair.';
    $brand_config['header_li_5'] = 'Infiniti Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Infiniti AC Service & Repair.';
    $brand_config['header_li_7'] = 'Infiniti Oil Change Service.';
    $brand_config['header_li_8'] = 'Infiniti Gearbox Repair.';
    $brand_config['header_li_9'] = 'Infiniti Engine Repair.';
    $brand_config['header_li_10'] = 'Infiniti Wheel Repair.';
    $brand_config['header_li_11'] = 'Infiniti Battery Repair.';
    $brand_config['header_li_12'] = 'Infiniti Tires Repair.';
    $brand_config['header_li_13'] = 'Infiniti Computer Reprogram.';
    $brand_config['header_li_14'] = 'Infiniti Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Infiniti Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Infiniti Electrical System Repair.';
    $brand_config['header_li_18'] = 'Infiniti Lighting System Repair.';
    $brand_config['header_li_19'] = 'Infiniti Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Infiniti Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/infiniti.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/infiniti-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/infiniti/infiniti-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Volvo Repair ***/
if(isset($_GET['volvo-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?volvo-repair";
    
    // Brand Name
    $brand_config['brand'] = "Volvo";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "In Dubai";

    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Repair.';
    $brand_config['header_li_3'] = 'Volvo Transmission Repair.';
    $brand_config['header_li_4'] = 'Volvo Suspension Repair.';
    $brand_config['header_li_5'] = 'Volvo Brake Pads Repair.';
    $brand_config['header_li_6'] = 'Volvo AC Service & Repair.';
    $brand_config['header_li_7'] = 'Volvo Oil Change Service.';
    $brand_config['header_li_8'] = 'Volvo Gearbox Repair.';
    $brand_config['header_li_9'] = 'Volvo Engine Repair.';
    $brand_config['header_li_10'] = 'Volvo Wheel Repair.';
    $brand_config['header_li_11'] = 'Volvo Battery Repair.';
    $brand_config['header_li_12'] = 'Volvo Tires Repair.';
    $brand_config['header_li_13'] = 'Volvo Computer Reprogram.';
    $brand_config['header_li_14'] = 'Volvo Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Rebuild.';
    $brand_config['header_li_16'] = 'Volvo Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Volvo Electrical System Repair.';
    $brand_config['header_li_18'] = 'Volvo Lighting System Repair.';
    $brand_config['header_li_19'] = 'Volvo Steering Repair.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Volvo Repair In Dubai.';
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/volvo-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/volvo-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/volvo/volvo-car.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Suspension
******************************************************************************************/

/*** Audi Suspension ***/
if(isset($_GET['audi-suspension'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-suspension";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Suspension";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Suspension Repair.';
    $brand_config['header_li_3'] = 'Audi Suspension & Inspection.';
    $brand_config['header_li_4'] = 'Audi Suspension & Programming.';
    $brand_config['header_li_5'] = 'Audi Transmission Repair.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Suspension In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Service
******************************************************************************************/

/*** Audi Service ***/
if(isset($_GET['audi-service'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-service";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Service";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Service.';
    $brand_config['header_li_3'] = 'Audi Transmission Service.';
    $brand_config['header_li_4'] = 'Audi Suspension Service.';
    $brand_config['header_li_5'] = 'Audi Brake Pads Service.';
    $brand_config['header_li_6'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_7'] = 'Audi Oil Change Service.';
    $brand_config['header_li_8'] = 'Audi Gearbox Service.';
    $brand_config['header_li_9'] = 'Audi Engine Service.';
    $brand_config['header_li_10'] = 'Audi Wheel Service.';
    $brand_config['header_li_11'] = 'Audi Battery Service.';
    $brand_config['header_li_12'] = 'Audi Tires Service.';
    $brand_config['header_li_13'] = 'Audi Computer Reprogram.';
    $brand_config['header_li_14'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Service.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Service.';
    $brand_config['header_li_17'] = 'Audi Electrical System Service.';
    $brand_config['header_li_18'] = 'Audi Lighting System Service.';
    $brand_config['header_li_19'] = 'Audi Steering Service.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Audi Car Service In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Workshop
******************************************************************************************/

/*** Audi workshop ***/
if(isset($_GET['audi-workshop'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-workshop";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Workshop";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_3'] = 'Audi Suspension & Inspection.';
    $brand_config['header_li_4'] = 'Audi Transmission & Inspection.';
    $brand_config['header_li_5'] = 'Audi Transmission Repair.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Workshop In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Garage
******************************************************************************************/

/*** Audi Garage ***/
if(isset($_GET['audi-garage'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-garage";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Garage";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_3'] = 'Audi Suspension & Inspection.';
    $brand_config['header_li_4'] = 'Audi Transmission & Inspection.';
    $brand_config['header_li_5'] = 'Audi Transmission Repair.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Garage In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Land Rover Garage ***/
if(isset($_GET['land-rover-garage'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?land-rover-garage";
    
    // Brand Name
    $brand_config['brand'] = "Land Rover";
    $brand_config['brand_title'] = "Garage";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Land Rover Engine Maintenance.';
    $brand_config['header_li_3'] = 'Land Rover Suspension & Inspection.';
    $brand_config['header_li_4'] = 'Land Rover Transmission & Inspection.';
    $brand_config['header_li_5'] = 'Land Rover Transmission Repair.';
    $brand_config['header_li_6'] = 'Land Rover Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Land Rover Maintenance.';
    $brand_config['header_li_8'] = 'Land Rover Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Land Rover Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Land Rover Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Land Rover Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Land Rover Oil Filter Service.';
    $brand_config['header_li_13'] = 'Land Rover Steering Repair.';
    $brand_config['header_li_14'] = 'Land Rover AC Service & Repair.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Land Rover Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Land Rover Electrical System Repair.';
    $brand_config['header_li_18'] = 'Land Rover Lighting System Repair.';
    $brand_config['header_li_19'] = 'Land Rover Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Land Rover Car Garage In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/land-rover.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/land-rover-animated-logo.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/land-rover/land-rover.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Engine Repair
******************************************************************************************/

/*** Audi Engine Repair ***/
if(isset($_GET['audi-engine-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-engine-repair";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Engine";
    $brand_config['brand_title_2'] = "Repair";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Engine Tuning.';
    $brand_config['header_li_3'] = 'Audi Engine Detailing.';
    $brand_config['header_li_4'] = 'Audi Engine Diagnosis.';
    $brand_config['header_li_5'] = 'Audi Transmission & Suspension.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'Audi Complete Engine Overhaul.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Engine Repair - Tuning - Detailing & Engine Diagnosis In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Specialist
******************************************************************************************/

/*** Audi Specialist ***/
if(isset($_GET['audi-specialist'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-specialist";
    
    // Brand Name
    $brand_config['brand'] = "Audi Car";
    $brand_config['brand_title'] = "Specialist";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Engine Tuning.';
    $brand_config['header_li_3'] = 'Audi Transmission & Suspension.';
    $brand_config['header_li_4'] = 'Audi Engine Diagnosis.';
    $brand_config['header_li_5'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_6'] = 'Audi Engine Detailing.';
    $brand_config['header_li_7'] = 'Audi Complete Engine Overhaul.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Audi Car Specialist In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Transmission
******************************************************************************************/

/*** Audi Transmission ***/
if(isset($_GET['audi-transmission'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-transmission";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Transmission Repair";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Transmission Repair.';
    $brand_config['header_li_3'] = 'Audi Transmission Inspection.';
    $brand_config['header_li_4'] = 'Audi Transmission Programming.';
    $brand_config['header_li_5'] = 'Transmission Oil Filter Service.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Body Damage Repair & Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Suspension Repair.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Transmission Repair In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Inspection
******************************************************************************************/

/*** Audi Inspection ***/
if(isset($_GET['audi-inspection'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-inspection";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Inspection";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_3'] = 'Audi Suspension & Inspection.';
    $brand_config['header_li_4'] = 'Audi Transmission & Inspection.';
    $brand_config['header_li_5'] = 'Audi Transmission Repair.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Body Damage Repair & Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Inspection & Suspension Repair In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Brake Pads
******************************************************************************************/

/*** Audi Brake Pads ***/
if(isset($_GET['audi-brake-pads'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-brake-pads";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Brake Pads Repair";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Brake Pads Replacement.';
    $brand_config['header_li_3'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_4'] = 'Audi Brake Pads Maintenance.';
    $brand_config['header_li_5'] = 'Audi Break Services.';
    $brand_config['header_li_6'] = 'Audi Brake Repair Specialist.';
    $brand_config['header_li_7'] = 'Audi Transmission & Suspension.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Brake Pads Repair - Brake Pads Replacement - Brake Pads Maintenance & Brake Pads Service In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Oil Change
******************************************************************************************/

/*** Audi Oil Change ***/
if(isset($_GET['audi-oil-change'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-oil-change";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Oil Change";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Oil & Filter Change.';
    $brand_config['header_li_3'] = 'Audi Oil Flushing.';
    $brand_config['header_li_4'] = 'Audi Premium Oil Change.';
    $brand_config['header_li_5'] = 'Audi Transmission & Suspension.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Oil & Filter Change Service In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Gearbox Repair
******************************************************************************************/

/*** Audi Gearbox Repair ***/
if(isset($_GET['audi-gearbox-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-gearbox-repair";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Gearbox Repair";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Gearbox Repair.';
    $brand_config['header_li_3'] = 'Audi Gearbox Service.';
    $brand_config['header_li_4'] = 'Audi Gearbox Oil Change.';
    $brand_config['header_li_5'] = 'Audi Transmission Repair.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Suspension Repair.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Body Damage Repair.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Gearbox Repair - Oil Change - Services & Maintenance In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Steering Repair
******************************************************************************************/

/*** Audi Steering Repair ***/
if(isset($_GET['audi-steering-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-steering-repair";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Steering Repair";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Complete Steering Repair.';
    $brand_config['header_li_3'] = 'Steering Wheel Repair.';
    $brand_config['header_li_4'] = 'Steering Rack Repair.';
    $brand_config['header_li_5'] = 'Power Steering Repair.';
    $brand_config['header_li_6'] = 'Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Suspension & Transmission.';
    $brand_config['header_li_12'] = 'Oil Filter Service.';
    $brand_config['header_li_13'] = '';
    $brand_config['header_li_14'] = 'AC Service & Repair.';
    $brand_config['header_li_15'] = 'Body Damage Repair.';
    $brand_config['header_li_16'] = 'Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Electrical System Repair.';
    $brand_config['header_li_18'] = 'Lighting System Repair.';
    $brand_config['header_li_19'] = 'Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Complete Audi Car Steering Repair Service In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Body Shop
******************************************************************************************/

/*** Audi Body Shop ***/
if(isset($_GET['audi-body-shop'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-body-shop";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Body Shop";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Audi Body Shop Damage Repair.';
    $brand_config['header_li_3'] = 'Audi Suspension & Inspection.';
    $brand_config['header_li_4'] = 'Audi Transmission & Maintenance.';
    $brand_config['header_li_5'] = 'Audi Transmission Repair.';
    $brand_config['header_li_6'] = 'Audi Major & Minor Services.';
    $brand_config['header_li_7'] = 'General Audi Maintenance.';
    $brand_config['header_li_8'] = 'Audi Engine Tuning & Diagnosis.';
    $brand_config['header_li_9'] = 'Audi Battery & Tires Repair.';
    $brand_config['header_li_10'] = 'Audi Brake Pads Repair.';
    $brand_config['header_li_11'] = 'Audi Computer Diagnostics.';
    $brand_config['header_li_12'] = 'Audi Oil Filter Service.';
    $brand_config['header_li_13'] = 'Audi Steering Repair.';
    $brand_config['header_li_14'] = 'Audi AC Service & Repair.';
    $brand_config['header_li_15'] = 'Audi Engine Maintenance.';
    $brand_config['header_li_16'] = 'Audi Glass / Windscreen Repair.';
    $brand_config['header_li_17'] = 'Audi Electrical System Repair.';
    $brand_config['header_li_18'] = 'Audi Lighting System Repair.';
    $brand_config['header_li_19'] = 'Audi Wheel Alignment & Repair.';

    $brand_config['header_p_des'] = 'We Are Specialized Audi Car Body Shop Repair In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
General
******************************************************************************************/

/*** Car Brake ***/
if(isset($_GET['car-brake-repair'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?car-brake-repair";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Car Brake Repair";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Car Brake Repair.';
    $brand_config['header_li_3'] = 'Car Brake Service.';
    $brand_config['header_li_4'] = 'Car Brake Replacement.';
    $brand_config['header_li_5'] = 'Car Brake Pad Replacement.';
    $brand_config['header_li_6'] = 'Car Brake Fluid Change.';
    $brand_config['header_li_7'] = 'Car Brake Light.';
    $brand_config['header_li_8'] = 'Car Brake Change.';
    $brand_config['header_li_9'] = 'Car Brake Oil.';
    $brand_config['header_li_10'] = 'Car Suspension & Transmission.';
    $brand_config['header_li_11'] = 'Car Major & Minor Services.';
    $brand_config['header_li_12'] = 'Car Engine Maintenance.';
    $brand_config['header_li_13'] = 'Car Wheel Alignment & Repair.';
    $brand_config['header_li_14'] = 'Car AC Service & Repair.';
    $brand_config['header_li_15'] = 'Car Battery & Tires Repair.';
    $brand_config['header_li_16'] = 'Car Computer Diagnostics.';
    $brand_config['header_li_17'] = '';
    $brand_config['header_li_18'] = '';
    $brand_config['header_li_19'] = '';

    $brand_config['header_p_des'] = 'We Are Specialized In Car Brake Repair In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Car Gearbox ***/
if(isset($_GET['car-gearbox-change'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?car-gearbox-change";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Gearbox Change - Rebuild";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Pickup And Inspection.';
    $brand_config['header_li_2'] = 'Car Gearbox Specialist.';
    $brand_config['header_li_3'] = 'Car Gearbox Rebuild.';
    $brand_config['header_li_4'] = 'Car Gearbox Change.';
    $brand_config['header_li_5'] = 'Car Gearbox Repair.';
    $brand_config['header_li_6'] = 'Car Gearbox Overhaul.';
    $brand_config['header_li_7'] = 'Car Gearbox & Transmission Repair.';
    $brand_config['header_li_8'] = 'Car Gearbox Repair and Replacement.';
    $brand_config['header_li_9'] = 'Car Gearbox & Wheel Alignment.';
    $brand_config['header_li_10'] = 'Car Suspension & Transmission.';
    $brand_config['header_li_11'] = 'Car Major & Minor Services.';
    $brand_config['header_li_12'] = 'Car Engine Maintenance.';
    $brand_config['header_li_13'] = 'Car Wheel Alignment & Repair.';
    $brand_config['header_li_14'] = 'Car AC Service & Repair.';
    $brand_config['header_li_15'] = 'Car Battery & Tires Repair.';
    $brand_config['header_li_16'] = 'Car Computer Diagnostics.';
    $brand_config['header_li_17'] = 'Car Service & Maintenance';
    $brand_config['header_li_18'] = '';
    $brand_config['header_li_19'] = '';

    $brand_config['header_p_des'] = 'We Are Specialized In Car Gearbox Repair & Replacment In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Car Workshop ***/
if(isset($_GET['cars-workshop'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?cars-workshop";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Cars Workshop";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Car Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Car Services.';
    $brand_config['header_li_3'] = 'German & European Cars Workshop.';
    $brand_config['header_li_4'] = 'Gearbox Oil Change & Repair.';
    $brand_config['header_li_5'] = 'Engine Repair & Rebuild.';
    $brand_config['header_li_6'] = 'Suspension & Steering Repair.';
    $brand_config['header_li_7'] = 'AC Repair & Service.';
    $brand_config['header_li_8'] = 'Car Damage Repair & Painting.';
    $brand_config['header_li_9'] = 'Electrical System Repair & Programming.';
    $brand_config['header_li_10'] = 'Oil Change Service.';
    $brand_config['header_li_11'] = 'Transmission Repair & Replacement.';
    $brand_config['header_li_12'] = 'Suspension Repair.';
    $brand_config['header_li_13'] = 'Wheel Repair & Painting.';
    $brand_config['header_li_14'] = 'Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Tires & Batteries Repair.';
    $brand_config['header_li_16'] = 'Car Steering Repair.';
    $brand_config['header_li_17'] = 'Brake Lighting System Repair.';
    $brand_config['header_li_18'] = 'Brake Repair & Replacement Servicing.';
    $brand_config['header_li_19'] = '';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized German & European Cars Workshop In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Car Mechanic ***/
if(isset($_GET['car-mechanic'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?car-mechanic";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Car Mechanic";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Car Pickup and Inspection.';
    $brand_config['header_li_2'] = 'Major & Minor Auto Service Mechanic.';
    $brand_config['header_li_3'] = 'German & European Car Mechanic.';
    $brand_config['header_li_4'] = 'Gearbox Oil Change & Repair.';
    $brand_config['header_li_5'] = 'Engine Repair & Rebuild Mechanic.';
    $brand_config['header_li_6'] = 'Suspension & Steering Repair Mechanic.';
    $brand_config['header_li_7'] = 'Auto AC Repair & Service Mechanic.';
    $brand_config['header_li_8'] = 'Car Damage Repair & Painting.';
    $brand_config['header_li_9'] = 'Auto Electrical Mechanic.';
    $brand_config['header_li_10'] = 'Oil Filter Change Service.';
    $brand_config['header_li_11'] = 'Transmission Repair & Replacement Mechanic.';
    $brand_config['header_li_12'] = 'Suspension Repair.';
    $brand_config['header_li_13'] = 'Wheel Repair & Painting.';
    $brand_config['header_li_14'] = 'Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Tires & Batteries Repair.';
    $brand_config['header_li_16'] = 'Car Steering Repair.';
    $brand_config['header_li_17'] = 'Brake Lighting System Repair.';
    $brand_config['header_li_18'] = 'Brake Repair & Replacement Servicing.';
    $brand_config['header_li_19'] = 'Expert Car Repair Mechanics.';

    $brand_config['header_p_des'] = 'We Are Certified & Specialized Car Mechanic In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Oil Change ***/
if(isset($_GET['oil-change'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?oil-change";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Car Oil Change";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Car Inspection.';
    $brand_config['header_li_2'] = 'Car Oil Change.';
    $brand_config['header_li_3'] = 'Car Oil Change Service.';
    $brand_config['header_li_4'] = 'Car Brake Oil Change.';
    $brand_config['header_li_5'] = 'Car Transmission Oil Change.';
    $brand_config['header_li_6'] = 'Car Oil Filter Change.';
    $brand_config['header_li_7'] = 'Car Engine Oil Change.';
    $brand_config['header_li_8'] = 'Car Steering Oil Change.';
    $brand_config['header_li_9'] = 'Car Gearbox Oil Change.';
    $brand_config['header_li_10'] = 'Oil Filter Change Service.';
    $brand_config['header_li_11'] = 'Car Oil Replacement.';
    $brand_config['header_li_12'] = 'Oil Pan Gasket Replacement.';
    $brand_config['header_li_13'] = 'Wheel Repair & Painting.';
    $brand_config['header_li_14'] = 'Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Tires & Batteries Repair.';
    $brand_config['header_li_16'] = 'Car Steering Repair.';
    $brand_config['header_li_17'] = 'Brake Lighting System Repair.';
    $brand_config['header_li_18'] = 'Brake Repair & Replacement Servicing.';
    $brand_config['header_li_19'] = 'Expert Car Repair Mechanics.';

    $brand_config['header_p_des'] = 'We Are Specialized In Car Oil Change Service In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Oil Leak ***/
if(isset($_GET['oil-leak'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?oil-leak";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Fix Car Oil Leak";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Car Inspection.';
    $brand_config['header_li_2'] = 'Fix Car Oil Leak.';
    $brand_config['header_li_3'] = 'Oil Leak Repair Shop & Workshop.';
    $brand_config['header_li_4'] = 'Fix Car Engine Oil Leak.';
    $brand_config['header_li_5'] = 'Fix Car Transmission Oil Leak.';
    $brand_config['header_li_6'] = 'Car Oil Filter Change.';
    $brand_config['header_li_7'] = 'Car Engine Oil Change.';
    $brand_config['header_li_8'] = 'Fix Car Steering Oil Leak.';
    $brand_config['header_li_9'] = 'Fix Car Gearbox Oil Leak.';
    $brand_config['header_li_10'] = 'Fix Oil Filter & Service.';
    $brand_config['header_li_11'] = 'Car Oil Replacement.';
    $brand_config['header_li_12'] = 'Oil Pan Gasket Replacement.';
    $brand_config['header_li_13'] = 'Wheel Repair & Painting.';
    $brand_config['header_li_14'] = 'Computer Diagnostics.';
    $brand_config['header_li_15'] = 'Tires & Batteries Repair.';
    $brand_config['header_li_16'] = 'Car Steering Repair.';
    $brand_config['header_li_17'] = 'Brake Lighting System Repair.';
    $brand_config['header_li_18'] = 'Brake Repair & Replacement Servicing.';
    $brand_config['header_li_19'] = 'Expert Car Repair Mechanics.';

    $brand_config['header_p_des'] = 'We Are Specialized Car Oil Leak Repair In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Oil Replacement ***/
if(isset($_GET['oil-replacement'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?oil-replacement";
    
    // Brand Name
    $brand_config['brand'] = "";
    $brand_config['brand_title'] = "Oil Replacement";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";
    
    // Header Key List
    $brand_config['header_li_1'] = 'Free Car Inspection.';
    $brand_config['header_li_2'] = 'Oil Pan Replacement.';
    $brand_config['header_li_3'] = 'Oil Cooler Replacement.';
    $brand_config['header_li_4'] = 'Oil Pump Replacement.';
    $brand_config['header_li_5'] = 'Oil Change Synthetic Oil.';
    $brand_config['header_li_6'] = 'Synthetic Oil Change.';
    $brand_config['header_li_7'] = 'Synthetic Oil Change Deals.';
    $brand_config['header_li_8'] = 'Oil Pan Gasket Replacement.';
    $brand_config['header_li_9'] = '24/7 Available - Call Now.';
    $brand_config['header_li_10'] = 'Oil Filter Gasket Replacement.';
    $brand_config['header_li_11'] = 'Oil Gasket Replacement.';
    $brand_config['header_li_12'] = 'Oil Consumption Fix.';
    $brand_config['header_li_13'] = 'Engine Oil Change.';
    $brand_config['header_li_14'] = 'Gearbox Oil Change.';
    $brand_config['header_li_15'] = 'Oil Filter & Service.';
    $brand_config['header_li_16'] = '.';
    $brand_config['header_li_17'] = '.';
    $brand_config['header_li_18'] = '.';
    $brand_config['header_li_19'] = '.';

    $brand_config['header_p_des'] = 'We Are Specialized In Car Oil Change & Replacement Garage In Dubai.';

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/general-logo.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/general-logo.png';
    $brand_config['brand_image'] = 'assets/img/about-us/about-us-img-1-1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

?>