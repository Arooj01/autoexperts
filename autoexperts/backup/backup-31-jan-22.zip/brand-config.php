<?php
$brand_page = false;
$brand_config = array(
    'head'=>'',
    'header'=>'',
    'about_section'=>'',
    'general_service'=>'',
    'work_process_section'=>'',
    'latest_project_section'=>'',
    'our_featured_section'=>'',
    'specialized_section'=>'',
    'footer_area'=>''
);

/*****************************************************************************************
Audi Cars Maintenance
******************************************************************************************/

/*** Audi Maintenance ***/
if(isset($_GET['audi-maintenance'])){
    
    // Brand URL
    $brand_config['brand_url'] = "?audi-maintenance";
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['footer_area'] = 'tpl/footer-area.tpl';
    
	$brand_page = true;
    
}

/*** Audi Maintenance Dubai ***/
if(isset($_GET['audi-maintenance-dubai'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi Car Maintenance ***/
if(isset($_GET['audi-car-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Car Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A1 Maintenance ***/
if(isset($_GET['audi-a1-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A1";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a1.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A3 Maintenance ***/
if(isset($_GET['audi-a3-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A4 Maintenance ***/
if(isset($_GET['audi-a4-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A4";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a4.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A5 Maintenance ***/
if(isset($_GET['audi-a5-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A6 Maintenance ***/
if(isset($_GET['audi-a6-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A6";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a6.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A7 Maintenance ***/
if(isset($_GET['audi-a7-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi A8 Maintenance ***/
if(isset($_GET['audi-a8-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi A8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-a8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q2 Maintenance ***/
if(isset($_GET['audi-q2-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi Q2";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q2.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q3 Maintenance ***/
if(isset($_GET['audi-q3-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi Q3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q5 Maintenance ***/
if(isset($_GET['audi-q5-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi Q5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q7 Maintenance ***/
if(isset($_GET['audi-q7-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi Q7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi Q8 Maintenance ***/
if(isset($_GET['audi-q8-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi Q8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-q8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi R8 Maintenance ***/
if(isset($_GET['audi-r8-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi R8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-r8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi S3 Maintenance ***/
if(isset($_GET['audi-s3-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi S3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS3 Maintenance ***/
if(isset($_GET['audi-rs3-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi RS3";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs3.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi S4 Maintenance ***/
if(isset($_GET['audi-s4-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi S4";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s4.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS4 Maintenance ***/
if(isset($_GET['audi-rs4-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi RS4";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs4.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi S5 Maintenance ***/
if(isset($_GET['audi-s5-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi S5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS5 Maintenance ***/
if(isset($_GET['audi-rs5-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi RS5";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s5.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi S6 Maintenance ***/
if(isset($_GET['audi-s6-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi S6";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s6.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS6 Maintenance ***/
if(isset($_GET['audi-rs6-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi RS6";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs6.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi S7 Maintenance ***/
if(isset($_GET['audi-s7-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi S7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi RS7 Maintenance ***/
if(isset($_GET['audi-rs7-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi RS7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-rs7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi S8 Maintenance ***/
if(isset($_GET['audi-s8-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi S8";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-s8.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi TT Maintenance ***/
if(isset($_GET['audi-tt-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi TT";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-tt.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Audi E Tron Maintenance ***/
if(isset($_GET['audi-e-tron-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi e-tron";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi-e-tron.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Aston Martin Cars Maintenance
******************************************************************************************/

/*** Aston Martin Maintenance ***/
if(isset($_GET['aston-martin-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Cygnet Maintenance ***/
if(isset($_GET['aston-martin-cygnet-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Cygnet";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-cygnet.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB10 Maintenance ***/
if(isset($_GET['aston-martin-db10-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB10";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB11 Maintenance ***/
if(isset($_GET['aston-martin-db11-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB11";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-db11.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB7 Maintenance ***/
if(isset($_GET['aston-martin-db7-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB7";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-db7.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DB9 Maintenance ***/
if(isset($_GET['aston-martin-db9-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DB9";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-db9.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin DBS Maintenance ***/
if(isset($_GET['aston-martin-dbs-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin DBS";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-dbs.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Lagonda Maintenance ***/
if(isset($_GET['aston-martin-lagonda-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Lagonda";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-lagonda.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin One 77 Maintenance ***/
if(isset($_GET['aston-martin-one-77-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin One 77";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-one-77.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Rapide Maintenance ***/
if(isset($_GET['aston-martin-rapide-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Rapide";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-rapide.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Vanquish Maintenance ***/
if(isset($_GET['aston-martin-vanquish-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Vanquish";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-vanquish.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Vantage Maintenance ***/
if(isset($_GET['aston-martin-vantage-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Vantage";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-vantage.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Virage Maintenance ***/
if(isset($_GET['aston-martin-virage-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Virage";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-virage.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Vulcan Maintenance ***/
if(isset($_GET['aston-martin-vulcan-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Vulcan";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-vulcan.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*** Aston Martin Zagato Maintenance ***/
if(isset($_GET['aston-martin-zagato-maintenance'])){
    
    // Brand Name
    $brand_config['brand'] = "Aston Martin Zagato";
    $brand_config['brand_title'] = "Maintenance";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/aston-martin.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/aston-martin.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/aston-martin/aston-martin-zagato.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Repair
******************************************************************************************/

/*** Audi Repair ***/
if(isset($_GET['audi-repair-dubai'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Repair";
    $brand_config['brand_title_2'] = "Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Suspension
******************************************************************************************/

/*** Audi Suspension ***/
if(isset($_GET['audi-suspension'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Suspension";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Service
******************************************************************************************/

/*** Audi Service ***/
if(isset($_GET['audi-service'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Service";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Workshop
******************************************************************************************/

/*** Audi workshop ***/
if(isset($_GET['audi-workshop'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Workshop";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Garage
******************************************************************************************/

/*** Audi Garage ***/
if(isset($_GET['audi-garage'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Garage";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Engine Repair
******************************************************************************************/

/*** Audi Engine Repair ***/
if(isset($_GET['audi-engine-repair'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Engine";
    $brand_config['brand_title_2'] = "Repair";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Specialist
******************************************************************************************/

/*** Audi Specialist ***/
if(isset($_GET['audi-specialist'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Specialist";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Transmission
******************************************************************************************/

/*** Audi Transmission ***/
if(isset($_GET['audi-transmission'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Transmission";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Inspection
******************************************************************************************/

/*** Audi Inspection ***/
if(isset($_GET['audi-inspection'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Inspection";
    $brand_config['brand_title_2'] = "In Dubai";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Brake Pads
******************************************************************************************/

/*** Audi Brake Pads ***/
if(isset($_GET['audi-brake-pads'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Brake Pads";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Oil Change
******************************************************************************************/

/*** Audi Oil Change ***/
if(isset($_GET['audi-oil-change'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Oil Change";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Gearbox Repair
******************************************************************************************/

/*** Audi Gearbox Repair ***/
if(isset($_GET['audi-gearbox-repair'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Gearbox Repair";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Steering Repair
******************************************************************************************/

/*** Audi Steering Repair ***/
if(isset($_GET['audi-steering-repair'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Steering Repair";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

/*****************************************************************************************
Cars Body Shop
******************************************************************************************/

/*** Audi Body Shop ***/
if(isset($_GET['audi-body-shop'])){
    
    // Brand Name
    $brand_config['brand'] = "Audi";
    $brand_config['brand_title'] = "Body Shop";
    $brand_config['brand_title_2'] = "";
    
    // Email, Call & Whatsapp # for landing page
    $brand_config['call_now'] = "042999908";
    $brand_config['whatsapp'] = "507786716";
    $brand_config['email'] = "info@autoexpertworkshop.com";

    // Images
    $brand_config['brand_logo'] = 'assets/img/brand/audi.jpg';
    $brand_config['brand_logo_animated'] = 'assets/img/brand/animated-logo/audi.png';
    $brand_config['brand_image'] = 'assets/img/brand-cars/audi/audi.jpg';
    
    // Sections & Pages
    $brand_config['head'] = 'tpl/brand-head.tpl';
    $brand_config['header'] = 'tpl/header.tpl';
    $brand_config['about_section'] = 'tpl/about.tpl';
    $brand_config['general_service'] = 'tpl/general-service.tpl';
    $brand_config['work_process_section'] = 'tpl/work-process.tpl';
    $brand_config['latest_project_section'] = 'tpl/latest-project.tpl';
    $brand_config['our_featured_section'] = 'tpl/our-featured.tpl';
    $brand_config['specialized_section'] = 'tpl/specialized.tpl';
    $brand_config['sidemenu'] = 'tpl/sidemenu-wrapper.tpl';
    
	$brand_page = true;
    
}

?>