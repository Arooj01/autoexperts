    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- lazysizes -->
    <script src="assets/js/lazysizes.min.js"></script>
    <!-- Ajax Mail -->
    <script src="assets/js/ajaxmail.js"></script>
    <!-- Main Js File -->
    <script src="assets/js/main.js"></script>