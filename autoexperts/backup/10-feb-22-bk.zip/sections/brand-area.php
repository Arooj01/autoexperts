    <div class="brand-area-wrapper brand-layout1 pt-100 pb-100">
        <!-- BG Shape -->
        <div class="bg-shape car-shape">
            <img src="assets/img/bg-img/car-1-1.png" alt="Modern Car">
        </div>

        <div class="container">
            <div class="row brand-slider1-active" data-aos="fade-up">

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/ferrari.jpg" alt="Ferrari">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/lamborghini.jpg" alt="Lamborghini">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/maserati.jpg" alt="Maserati">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/rolls-royce.jpg" alt="Rolls Royce">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/bentley.jpg" alt="Bentley">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/aston-martin.jpg" alt="Aston Martin">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/audi.jpg" alt="Audi">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/chevrolet.jpg" alt="Chevrolet">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/bmw.jpg" alt="BMW">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/porsche.jpg" alt="Porsche">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/mercedes.jpg" alt="Mercedes">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/dodge.jpg" alt="Dodge">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/land-rover.jpg" alt="Land Rover">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/ford.jpg" alt="Ford">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/volkswagen.jpg" alt="Volkswagen">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/jaguar.jpg" alt="Jaguar">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/infiniti.jpg" alt="Infiniti">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/lexus.jpg" alt="Lexus">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/jeep.jpg" alt="Jeep">
                    </div>
                </div>

                <!-- Single Brand -->
                <div class="col-xl-3">
                    <div class="brand-box">
                        <img src="assets/img/brand/gmc.jpg" alt="GMC">
                    </div>
                </div>

            </div><!-- .row END -->
        </div><!-- .container END -->
    </div>